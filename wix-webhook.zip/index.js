const print = require("./print")

exports.handler = async(event) => {
    console.log(event)
    print("if this works we good")
}
